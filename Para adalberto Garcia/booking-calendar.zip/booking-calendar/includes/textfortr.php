<?php
__('January', 'booking-calendar');
__('February', 'booking-calendar');
__('March', 'booking-calendar');
__('April', 'booking-calendar');
__('May', 'booking-calendar');
__('June', 'booking-calendar');
__('July', 'booking-calendar');
__('August', 'booking-calendar');
__('September', 'booking-calendar');
__('October', 'booking-calendar');
__('November', 'booking-calendar');
__('December', 'booking-calendar');


__('Jan', 'booking-calendar');
__('Feb', 'booking-calendar');
__('Mar', 'booking-calendar');
__('Apr', 'booking-calendar');
__('May', 'booking-calendar');
__('Jun', 'booking-calendar');
__('Jul', 'booking-calendar');
__('Aug', 'booking-calendar');
__('Sep', 'booking-calendar');
__('Oct', 'booking-calendar');
__('Nov', 'booking-calendar');
__('Dec', 'booking-calendar');


__('Sunday', 'booking-calendar');
__('Monday', 'booking-calendar');
__('Tuesday', 'booking-calendar');
__('Wednesday', 'booking-calendar');
__('Thursday', 'booking-calendar');
__('Friday', 'booking-calendar');
__('Saturday', 'booking-calendar');


__('Sun', 'booking-calendar');
__('Mon', 'booking-calendar');
__('Tue', 'booking-calendar');
__('Wed', 'booking-calendar');
__('Thu', 'booking-calendar');
__('Fri', 'booking-calendar');
__('Sat', 'booking-calendar');


__('Su', 'booking-calendar');
__('Mo', 'booking-calendar');
__('Tu', 'booking-calendar');
__('We', 'booking-calendar');
__('Th', 'booking-calendar');
__('Fr', 'booking-calendar');
__('Sa', 'booking-calendar');


__("available","booking-calendar");
__("Booked","booking-calendar");
__("Unavailable","booking-calendar");
__("Check in","booking-calendar");
__("Check out","booking-calendar");
__("No hour available.","booking-calendar");
__("Start hour","booking-calendar");
__("End hour","booking-calendar");
__("Item count","booking-calendar");
__("I accept to agree to the Terms & Conditions.","booking-calendar");
__("Reservation","booking-calendar");
__("Please select the days from calendar.","booking-calendar");
__("Price","booking-calendar");
__("Total","booking-calendar");
__("Book Now","booking-calendar");
__("Your request has been successfully sent. Please wait for approval.","booking-calendar");
__("Your request has been successfully received. We are waiting you!","booking-calendar");
__("There are no services available for this day.","booking-calendar");
__("There are no services available for the period you selected.","booking-calendar");
__("Email on book to administrator doesn't send","booking-calendar");
__("Email on approved to administrator doesn't send","booking-calendar");
__( "Email on book to user doesn't send","booking-calendar");
__("Email on approved to user doesn't send","booking-calendar");
__("Email on canceled to user doesn't send","booking-calendar");
__("Email on delete to user doesn't send","booking-calendar")


?>